@extends("layouts.app")
@section("content")
    <div>
        <div class="msg_box" style="right:340px">
            <div class="msg_head">Chat General

            </div>
            <div class="msg_wrap">
                <div id="chat" class="msg_body">

                </div>
                <div class="msg_footer"><textarea class="msg_input" rows="4"></textarea></div>
            </div>
        </div>

    @endsection