@extends('layouts.app')

@section('content')
    @include("parcial.Mensajes")
    <div class="container">
        <div class="row">

            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Carreras disponibles para apostar</div>

             <form method="post" action="{{url("/apuestas")}}">
                    <input name="invisible" type="hidden" value="{{$count=0}}">
                 <input name="id_cliente" type="hidden" value="{{Auth::user()->id}}">
                 {{csrf_field()}}
                    @foreach($pollas as $polla)
                        <input name="invisible" type="hidden" value="{{$count=$count+1}}">
                        <input name="id_polla{{$count}}" type="hidden" value="{{$polla->id_polla}}">
                        <div class="panel-body">

                            <div class="panel form-horizontal col-md-4">
                                <div class="form-group">
                                    <label class="col-md-4 control-label">Tipo de Carrera</label>
                                    <div class="col-md-7">
                                        <input type="text" class="form-control" name="name" value="{{ $polla->name}} ">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-4 control-label">Pago</label>

                                    <div class="col-md-7">
                                        <input type="text" class="form-control" name="name" value="{{ $polla->pago}} ">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-4 control-label">Fecha</label>

                                    <div class="col-md-7">
                                        <input type="text" class="form-control" name="name" value="{{ $polla->fecha}} ">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-4 control-label">Hora</label>

                                    <div class="col-md-7">
                                        <input type="text" class="form-control" name="name" value="{{ $polla->hora}} ">
                                    </div>
                                </div>
                            </div>

                            <div class="panel col-md-7">

                                @foreach($caballos as $caballo)
                                    @if($polla->id_polla === $caballo->id_polla)
                                        <div class="radio" role="group" {{ $errors->has("id_caballo".$count) ? ' has-error' : '' }}>

                                            <label>
                                                <input type="radio" name="id_caballo{{$count}}" value="{{$caballo->id_caballo}}" >
                                                Nombre: {{$caballo->propietario}} || Jinete: {{$caballo->jinete}} || MI: {{$caballo->mi}} || Peso: {{$caballo->peso}}
                                            </label>
                                        </div>
                                    @endif
                                @endforeach
                            </div>

                        </div>
                    @endforeach
                 <button type="submit" class="btn-lg btn-primary center-block">
                     <i class="fa fa-btn fa-user"></i>APOSTAR!!
                 </button>
             </form>
                </div>
            </div>
        </div>
    </div>
    <script>

        $('.datepicker').datepicker({
            format: "yyyy/mm/dd",
            language: "es",
            autoclose: true
        });
    </script>
@endsection