<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8">
</head>
<body>
<center>
    <img src=" {{asset("/img/logo-mail.jpg")}}">
</center>
<h4>Correo de confirmacion de polla</h4>


<div>

    <br>Gracias por confiar en  TuPollaUSA<br/>

    <br>El estado de tu pago es : <b>{{$estado}}</b><br/>

    <br>El monto de su pago fue : <b>{{$monto}}</b><br/>
    <br><br/>
    <br><br/>
    <br>Le recordamos que su pago es aprobado sera acreditado de INMEDIATO<br/>
    <br>si su pago esta en "PENDING" sera acreditado cuando cambie al estado "APROBADO"<br/>
</div>

</body>
</html>