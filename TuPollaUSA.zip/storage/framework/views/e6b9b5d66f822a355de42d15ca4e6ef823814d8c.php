<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">

            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Agregar Caballos</div>
                    <div class="panel-body">
                        <div class="alert alert-success" role="alert">Le recordamos que el registro no se podra modificar en el futuro.</div>
                        <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/admin/add/caballos')); ?>">
                            <?php echo csrf_field(); ?>


                            <div class="form-group<?php echo e($errors->has('id_polla') ? ' has-error' : ''); ?>">


                                <div class="col-md-6">
                                    <input type="hidden" class="form-control" name="id_master" value="<?php echo e($polla->id_polla); ?>">

                                    <?php if($errors->has('id_master')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('id_master')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('id_polla') ? ' has-error' : ''); ?>">


                                <div class="col-md-6">
                                    <input type="hidden" class="form-control" name="id_polla" value="<?php echo e(Auth::user()->id); ?>">

                                    <?php if($errors->has('id_master')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('id_master')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Nombre</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="name" value="<?php echo e(old("name")); ?>" >

                                    <?php if($errors->has('name')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Posicion</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="posicion" value="<?php echo e($count); ?>"  readonly>

                                    <?php if($errors->has('name')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('propietario') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Propietario</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="propietario" placeholder="Hebert Ramirez" value="<?php echo e(old('porpietario')); ?>">

                                    <?php if($errors->has('propietario')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('propietario')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('jinete') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Jinete</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="jinete" placeholder="Carlos Paternina" value="<?php echo e(old('jinete')); ?>">

                                    <?php if($errors->has('jinete')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('jinete')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('peso') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Peso</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="peso" placeholder="132" value="<?php echo e(old('peso')); ?>">

                                    <?php if($errors->has('peso')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('peso')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('mi') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">MI</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="mi" placeholder=12/1" value="<?php echo e(old('mi')); ?>">

                                    <?php if($errors->has('mi')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('mi')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-6 col-md-offset-4">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fa fa-btn fa-user"></i>Agregar Caballo
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>

        $('.datepicker').datepicker({
            format: "yyyy/mm/dd",
            language: "es",
            autoclose: true
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>