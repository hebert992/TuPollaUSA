<?php $__env->startSection('content'); ?>
<p>
<h3 class="text-center">Pagos con Targeta de credito</h3>
Los pagos con targeta de credito a TupollaUSA.com son gestionados a traves de la plataforma de mercadopago, es muy facil, solo tienes que selecionar la cantidad de coins a recargar y se te sera redirigido a la pagina de mercado pago  donde podras ingresar tus datos y hacer el correspondiente pago con TDC y seran acreditados en tu cuenta de TupollaUSA
</p>
<div class="panel panel-default">
    <form action="<?php echo e(url("/mercadopago/pagar")); ?>" method="post">
        <?php echo e(csrf_field()); ?>

    <select class="form-control" name="cantidad">
        <?php for($a=1;$a<11;$a++): ?>

                <option value="<?php echo e($a); ?>"><?php echo e($a); ?></option >

        <?php endfor; ?>
    </select>
<button type="submit">
    <a mp-mode="dftl"  name="MP-payButton" class='blue-ar-l-rn-none'>Pagar</a>
</button>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app2", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>