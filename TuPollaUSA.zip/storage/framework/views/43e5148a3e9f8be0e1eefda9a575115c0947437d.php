<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="panel col-md-13 ">
            <div class="panel panel-default ">
                <div class="panel-heading">Lista de usuario</div>
               <?php echo $__env->make("parcial.Mensajes", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                     <div class="panel-body">

                         <?php if( Auth::user()->rol=="admin"): ?>
                             <a class="btn btn-info" href="<?php echo e(url('/admin/registro')); ?>" role="button">
                                 Nueva Tienda
                             </a>
                         <?php endif; ?>
                             <?php if( Auth::user()->rol=="tienda"): ?>
                                 <a class="btn btn-info" href="<?php echo e(url('/tienda/registro')); ?>" role="button">
                                     Nuevo usuario
                                 </a>
                             <?php endif; ?>

                         <form class="navbar-form navbar-right" role="search"method="GET" >

                                 <input type="text" class="form-control"  name="name"  placeholder="Nombre del cliente"  >

                             <button type="submit" class="btn btn-default">Buscar</button>
                         </form>
                         <table class="table table-striped">



                             <tr>
                                 <th>ID</th>
                                 <th>Stud</th>
                                 <th>Nombre</th>
                                 <th>Correo</th>
                                 <th>Coins</th>
                                 <?php if( Auth::user()->rol=="admin"): ?>
                                     <th>Creado por</th>
                                 <?php endif; ?>
                                 <th>Acciones</th>
                                 
                             </tr>
                             <?php foreach( $users as $user): ?>
                             <tr>
                                 <td><?php echo e($user->id); ?></td>
                                 <td><?php echo e($user->nick); ?></td>
                                 <td><?php echo e($user->name); ?></td>
                                 <td><?php echo e($user->email); ?></td>
                                 <td><?php echo e($user->coins); ?></td>
                                 <?php if( Auth::user()->rol=="admin"): ?>
                                     <td><?php echo e($user->id_master); ?>-<?php echo e($user->master); ?></td>
                                 <?php endif; ?>

                                 <td>
                                     <div class="btn-group">
                                         <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                             Herramientas <span class="caret"></span>
                                         </button>
                                         <ul class="dropdown-menu">
                                             <li><a href="/admin/recarga/<?php echo e($user->id); ?>">Recarga</a></li>
                                             <li><a href="/admin/editar/<?php echo e($user->id); ?>">Editar</a></li>
                                             <li><a href="/tienda/apostar/<?php echo e($user->id); ?>">Apostar</a></li>
                                             <li role="separator" class="divider"></li>
                                             <li><a data-toggle="modal" data-target="#<?php echo e($user->id); ?>" href="#">Eliminar</a></li>
                                         </ul>
                                     </div>

                                 </td>
                             </tr>
                                 <!-- Small modal -->


                                 <div class="modal fade" id="<?php echo e($user->id); ?>" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
                                     <div class="modal-dialog modal-sm">
                                         <div class="modal-content">
                                             <div class="modal-header">
                                                 <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                                 <h4 class="modal-title">Seguro de Eliminar a  <?php echo e($user->nick); ?></h4>
                                             </div>
                                             <div class="modal-body">

                                                 <form class="row" method="post" action="<?php echo e(url('/admin/borrar')); ?>">


                                                     <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                                         <label class="col-xs-8 .col-sm-6 control-label">ID del Stud</label>
                                                         <input type="text" class="form-control  .col-xs-4 .col-sm-6" name="id" value="<?php echo e($user->id); ?>" readonly>
                                                     </div>
                                                     <?php echo csrf_field(); ?>

                                                     <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                                         <label class="col-xs-8 .col-sm-6 control-label">Nombre Real</label>
                                                         <input type="text" class="form-control  .col-xs-4 .col-sm-6" name="name" value="<?php echo e($user->name); ?>" readonly>
                                                     </div>
                                                     <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                                         <label class="col-xs-8 .col-sm-6 control-label">Tipo de Usuario</label>
                                                         <input type="text" class="form-control  .col-xs-4 .col-sm-6" name="rol" value="<?php echo e($user->rol); ?>" readonly>
                                                     </div>




                                             </div>
                                             <div class="modal-footer">

                                                 <button type="submit" class="btn btn-primary">Eliminar a <?php echo e($user->nick); ?></button>
                                                 </form>
                                             </div>
                                         </div><!-- /.modal-content -->
                                     </div><!-- /.modal-dialog -->
                                 </div><!-- /.modal -->
                                 </div>
                             <?php endforeach; ?>
                         </table>
                         
                         <?php echo $users->render(); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>