<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <?php echo $__env->make("parcial.Mensajes", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <div class="panel-heading">Lista de Pollas</div>

                    <div class="panel-body">


                        <div class="panel-body">

                            <?php if( Auth::user()->rol=="admin"): ?>
                                <a class="btn btn-info" href="<?php echo e(url('/admin/add/polla')); ?>" role="button">
                                    Nueva Carrera
                                </a>
                            <?php endif; ?>


                            <form class="navbar-form navbar-right" role="search"method="GET" >

                                <input type="text" class="form-control"  name="name"  placeholder="Buscar tipo de polla"  >

                                <button type="submit" class="btn btn-default">Buscar</button>
                            </form>


                        <table class="table table-striped">



                            <tr>
                                <th>Tipo</th>
                                <th>Hipodromo</th>
                                <th>Terreno</th>
                                <th>Pago</th>
                                <th>Fecha y Hora</th>

                                <th>Distancia</th>
                                <th>Acciones</th>


                            </tr>
                            <?php foreach( $pollas as $polla): ?>
                                <tr>
                                    <td><?php echo e($polla->name); ?></td>
                                    <td><?php echo e($polla->hipodromo); ?></td>
                                    <td><?php echo e($polla->terreno); ?></td>
                                    <td><?php echo e($polla->pago); ?></td>
                                    <td><?php echo e($polla->fecha); ?></td>
                                    <td><?php echo e($polla->distancia); ?></td>

                                    <td>
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                Herramientas <span class="caret"></span>
                                            </button>
                                            <ul class="dropdown-menu">
                                                <li><a href="<?php echo e(url("/admin/polla/$polla->id_polla/caballos")); ?>">Caballos</a></li>
                                                <li><a href="<?php echo e(url("/admin/add/caballo/$polla->id_polla")); ?>">Agregar Caballos</a></li>
                                                <li><a href="<?php echo e(url("/admin/add/resultado/$polla->id_polla")); ?>">Agregar Resultados</a></li>
                                                <li role="separator" class="divider"></li>
                                                <li><a href="<?php echo e(url("/admin/polla/editar/$polla->id_polla")); ?>">Editar Carrera</a></li>

                                            </ul>

                                        </div>

                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </table>


                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>