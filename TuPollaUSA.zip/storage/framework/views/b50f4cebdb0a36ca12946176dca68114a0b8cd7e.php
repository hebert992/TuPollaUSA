<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading">Lista de usuario</div>

                    <div class="panel-body">

                        <?php if( Auth::user()->rol=="admin"): ?>
                            <a class="btn btn-info" href="<?php echo e(url('/admin/registro')); ?>" role="button">
                                Nueva Tienda
                            </a>
                        <?php endif; ?>
                        <?php if( Auth::user()->rol=="tienda"): ?>
                            <a class="btn btn-info" href="<?php echo e(url('/tienda/registro')); ?>" role="button">
                                Nuevo usuario
                            </a>
                        <?php endif; ?>

                        <form class="navbar-form navbar-right" role="search"method="GET" >

                            <input type="text" class="form-control"  name="name"  placeholder="Nombre del cliente"  >

                            <button type="submit" class="btn btn-default">Buscar</button>
                        </form>
                        <table class="table table-striped">



                            <tr>
                                <th>ID</th>
                                <th>Stud</th>
                                <th>Nombre</th>
                                <th>Correo</th>
                                <th>Coins</th>
                                <?php if( Auth::user()->rol=="admin"): ?>
                                    <th>Creado por</th>
                                <?php endif; ?>
                                <th>Acciones</th>

                            </tr>
                            <?php foreach( $users as $user): ?>
                                <tr>
                                    <td><?php echo e($user->id); ?></td>
                                    <td><?php echo e($user->nick); ?></td>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->coins); ?></td>
                                    <?php if( Auth::user()->rol=="admin"): ?>
                                        <td><?php echo e($user->id_master); ?>-<?php echo e($user->master); ?></td>
                                    <?php endif; ?>

                                    <td>
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                Herramientas <span class="caret"></span>
                                            </button>
                                            <ul class="dropdown-menu">
                                                <li><a href="/admin/tiendas/<?php echo e($user->id); ?>">Ultimos movimientos</a></li>
                                                <li><a href="">Editar</a></li>
                                                <li><a href="#">Suspender</a></li>
                                                <li role="separator" class="divider"></li>
                                                <li><a href="#">Eliminar</a></li>
                                            </ul>
                                        </div>

                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </table>

                        <?php echo $users->render(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>