<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Edicion del Stud <?php echo e($user->nick); ?></div>
                    <div class="panel-body">
                        <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/admin/editar')); ?>" >
                            <?php echo csrf_field(); ?>

                            <div class="form-group<?php echo e($errors->has('nick') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">ID de Stud</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="id" value="<?php echo e($user->id); ?>" readonly>

                                    <?php if($errors->has('nick')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('nick')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('nick') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Nombre de Usuario</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="nick" value="<?php echo e($user->nick); ?>" readonly>

                                    <?php if($errors->has('nick')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('nick')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Correo</label>

                                <div class="col-md-6">
                                    <input type="email" class="form-control" name="email" value="<?php echo e($user->email); ?>">

                                    <?php if($errors->has('email')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Nombre Completo</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>">

                                    <?php if($errors->has('name')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('telefono') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Telefono</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="telefono" value="<?php echo e($user->telefono); ?>">

                                    <?php if($errors->has('telefono')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('telefono')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('pais') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Pais</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="pais" value="<?php echo e($user->pais); ?>">

                                    <?php if($errors->has('pais')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('pais')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('ciudad') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Ciudad</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="ciudad" value="<?php echo e($user->ciudad); ?>">

                                    <?php if($errors->has('ciudad')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('ciudad')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('direccion') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Direccion</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="direccion" value="<?php echo e($user->ciudad); ?>">

                                    <?php if($errors->has('direccion')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('direccion')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>


                            <div class="form-group<?php echo e($errors->has('date') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Fecha de Nacimiento</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control  datepicker" name="date" value="<?php echo e($user->date); ?>">

                                    <?php if($errors->has('date')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('date')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>


                            <div class="form-group<?php echo e($errors->has('tipo') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Tipo de Usuario</label>

                                <div class="col-md-6">
                                    <select class="form-control"  >
                                        <option><?php echo e($user->rol); ?></option>

                                        <option>admin</option>
                                        <option>tienda</option>

                                    </select>
                                    <?php if($errors->has('tipo')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('tipo')); ?></strong>
                                    </span>
                                    <?php endif; ?>


                                </div>
                            </div>


                            <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Contraseña</label>

                                <div class="col-md-6">
                                    <input type="password" class="form-control" name="password">

                                    <?php if($errors->has('password')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Confirmar contraseña</label>

                                <div class="col-md-6">
                                    <input type="password" class="form-control" name="password_confirmation">

                                    <?php if($errors->has('password_confirmation')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-6 col-md-offset-4">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fa fa-btn fa-user"></i>Actualizar
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        $('.datepicker').datepicker({
            format: "yyyy/mm/dd",
            language: "es",
            autoclose: true
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>