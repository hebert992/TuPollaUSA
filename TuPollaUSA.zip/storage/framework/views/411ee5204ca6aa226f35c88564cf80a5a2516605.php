<div>
    <script src="<?php echo e(asset('ckeditor\ckeditor.js')); ?>"></script>
    <script src="<?php echo e(asset('ckeditor\samples\js\sample.js')); ?>"></script>

    <link rel="stylesheet" href="<?php echo e(asset(('ckeditor\samples\css\sample.css'))); ?>">

    <!--- Titulo Field --->

    <?php echo Form::label('titulo', 'Titulo:'); ?>

    <?php echo Form::text('titulo', null, ['class' => 'form-control']); ?>



<!--- Contenido Field --->

    <?php echo Form::label('contenido', 'Contenido:'); ?>

    <?php echo Form::textarea('contenido', null, ['class' => 'form-control','id' => 'editor']); ?>



<!--- Autor Field --->

    <?php echo Form::label('autor', 'Autor:'); ?>

    <?php echo Form::text('autor', null, ['class' => 'form-control','readonly' => 'readonly' ]); ?>




<!--- Submit Field --->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>

</div>
    <script>
        initSample();
    </script>
