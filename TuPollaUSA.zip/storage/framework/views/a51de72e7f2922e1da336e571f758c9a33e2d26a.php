<?php $__env->startSection('content'); ?>
    <?php echo $__env->make("parcial.Mensajes", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


        <div class="panel-body">
            <b> Selecciona un caballo para Cada una de las carreras verifica tu seleccion y cuando estes listo dale al boton enviar polla </b>
        </div>
    <form action="<?php echo e(url("/apuestas")); ?>" method="post">
        <?php echo e(csrf_field()); ?>

    <input type="hidden" class="form-control" name="id_nada" value="<?php echo e($count=0); ?>">
    <input type="hidden" class="form-control" name="id_cliente" value="<?php echo e(Auth::user()->id); ?>">
    <?php foreach($pollas as $polla): ?>
        <div class="panel panel-default">
            <div class="panel-heading">Carrera <?php echo e($polla->id_polla); ?> <?php echo e($polla->hipodromo); ?>   TupollaUSA.com <?php echo e($polla->fecha); ?> </div>
            <input type="hidden" class="form-control" name="id_nada" value="<?php echo e($count+=1); ?>">
            <input type="hidden" class="form-control" name="id_polla<?php echo e($count); ?>" value="<?php echo e($polla->id_polla); ?>">

            <div class="panel-body">
                <p>
                    Seleccione el caballo de su preferencia para esta carrera
                </p>
                <select id="id<?php echo e($count); ?>"class="form-control" name="id_caballo<?php echo e($count); ?>" >
                    <?php foreach($caballos as $caballo): ?>
                    <?php if($polla->id_polla === $caballo->id_polla): ?>
                    <option value="<?php echo e($caballo->id_caballo); ?>"><?php echo e($caballo->posicion); ?></option >
                    <?php endif; ?>
                    <?php endforeach; ?>
                </select>
                <div class="panel-body" id="body<?php echo e($count); ?>">

                </div>

            </div>



        </div>
    <?php endforeach; ?>
        <div class="form-group">
            <div class="col-md-6 col-md-offset-4">
                <button type="button" data-target="#modal" data-toggle="modal" class="btn btn-primary">
                    <i class="btn-lg">APOSTAR!</i>
                    <br>
                </button>
            </div>
        </div>
        <div class="modal fade" tabindex="-1" role="dialog" id="modal">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title">CONFIRMACION</h4>
                    </div>
                    <div class="modal-body">
                        <p>Estas seguro de tu apuesta?</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary">APOSTAR</button>
                    </div>
                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div><!-- /.modal -->
    </form>

    <script src="<?php echo e(asset('js/caballos.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>