<?php $__env->startSection('content'); ?>
    <?php echo $__env->make("parcial.Mensajes", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="container">
        <div class="row">

            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Carreras disponibles para apostar</div>

             <form method="post" action="<?php echo e(url("/apuestas")); ?>">
                    <input name="invisible" type="hidden" value="<?php echo e($count=0); ?>">
                 <input name="id_cliente" type="hidden" value="<?php echo e(Auth::user()->id); ?>">
                 <?php echo e(csrf_field()); ?>

                    <?php foreach($pollas as $polla): ?>
                        <input name="invisible" type="hidden" value="<?php echo e($count=$count+1); ?>">
                        <input name="id_polla<?php echo e($count); ?>" type="hidden" value="<?php echo e($polla->id_polla); ?>">
                        <div class="panel-body">

                            <div class="panel form-horizontal col-md-4">
                                <div class="form-group">
                                    <label class="col-md-4 control-label">Tipo de Carrera</label>
                                    <div class="col-md-7">
                                        <input type="text" class="form-control" name="name" value="<?php echo e($polla->name); ?> ">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-4 control-label">Pago</label>

                                    <div class="col-md-7">
                                        <input type="text" class="form-control" name="name" value="<?php echo e($polla->pago); ?> ">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-4 control-label">Fecha</label>

                                    <div class="col-md-7">
                                        <input type="text" class="form-control" name="name" value="<?php echo e($polla->fecha); ?> ">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-4 control-label">Hora</label>

                                    <div class="col-md-7">
                                        <input type="text" class="form-control" name="name" value="<?php echo e($polla->hora); ?> ">
                                    </div>
                                </div>
                            </div>

                            <div class="panel col-md-7">

                                <?php foreach($caballos as $caballo): ?>
                                    <?php if($polla->id_polla === $caballo->id_polla): ?>
                                        <div class="radio" role="group" <?php echo e($errors->has("id_caballo".$count) ? ' has-error' : ''); ?>>

                                            <label>
                                                <input type="radio" name="id_caballo<?php echo e($count); ?>" value="<?php echo e($caballo->id_caballo); ?>" >
                                                Nombre: <?php echo e($caballo->propietario); ?> || Jinete: <?php echo e($caballo->jinete); ?> || MI: <?php echo e($caballo->mi); ?> || Peso: <?php echo e($caballo->peso); ?>

                                            </label>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </div>

                        </div>
                    <?php endforeach; ?>
                 <button type="submit" class="btn-lg btn-primary center-block">
                     <i class="fa fa-btn fa-user"></i>APOSTAR!!
                 </button>
             </form>
                </div>
            </div>
        </div>
    </div>
    <script>

        $('.datepicker').datepicker({
            format: "yyyy/mm/dd",
            language: "es",
            autoclose: true
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>