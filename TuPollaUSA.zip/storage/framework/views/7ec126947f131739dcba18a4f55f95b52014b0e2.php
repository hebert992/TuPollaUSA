<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">

            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Agregando polla</div>
                    <div class="panel-body">
                        <div class="alert alert-success" role="alert">Le recordamos que el registro no se podra modificar en el futuro.</div>
                        <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/admin/add/polla')); ?>">
                            <?php echo csrf_field(); ?>


                            <div class="form-group<?php echo e($errors->has('id_master') ? ' has-error' : ''); ?>">


                                <div class="col-md-6">
                                    <input type="hidden" class="form-control" name="id_master" value="<?php echo e(Auth::user()->id); ?>">

                                    <?php if($errors->has('id_master')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('id_master')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>


                            <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Tipo de Polla</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>">

                                    <?php if($errors->has('name')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('hipodromo') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Hipodromo</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="hipodromo" value="<?php echo e(old('hipodromo')); ?>">

                                    <?php if($errors->has('hipodromo')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('hipodromo')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('pago') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Pago</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="pago" value="<?php echo e(old('pago')); ?>">

                                    <?php if($errors->has('pago')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('pago')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('distancia') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Distancia</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="distancia" value="<?php echo e(old('distancia')); ?>">

                                    <?php if($errors->has('distancia')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('distancia')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>


                            <div class="form-group<?php echo e($errors->has('fecha') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Fecha de Corrida</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control datepicker" name="fecha" value="<?php echo e(old('fecha')); ?>">

                                    <?php if($errors->has('fecha')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('fecha')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('hora') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Hora de la Corrida</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control time" name="hora" id="#time" placeholder="Ejemplo : 21:41:00" value="<?php echo e(old('hora')); ?>">

                                    <?php if($errors->has('hora')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('hora')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>


                            <div class="form-group<?php echo e($errors->has('terreno') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Terreno</label>

                                <div class="col-md-6">
                                    <select class="form-control" name="tipo">
                                        <option>Seleciona el Terreno de la Carrera</option>

                                        <option>arena</option>
                                        <option>grava</option>
                                        <option>sesped</option>

                                    </select>
                                    <?php if($errors->has('tipo')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('tipo')); ?></strong>
                                    </span>
                                    <?php endif; ?>


                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('caballos_numero') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Cantida de Caballos</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="caballos_numero" value="<?php echo e(old('caballos_numero')); ?>">

                                    <?php if($errors->has('caballos_numero')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('caballos_numero')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>








                            <div class="form-group">
                                <div class="col-md-6 col-md-offset-4">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fa fa-btn fa-user"></i>Agregar Polla
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>

        $('.datepicker').datepicker({
            format: "yyyy/mm/dd",
            language: "es",
            autoclose: true
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>