<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">

            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Agregando polla</div>
                    <div class="panel-body">
                        <div class="alert alert-success" role="alert">Le recordamos que el registro no se podra modificar en el futuro.</div>
                        <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/admin/add/polla')); ?>">
                            <?php echo csrf_field(); ?>


                            <div class="form-group<?php echo e($errors->has('id_master') ? ' has-error' : ''); ?>">


                                <div class="col-md-6">
                                    <input type="hidden" class="form-control" name="id_master" value="<?php echo e(Auth::user()->id); ?>">

                                    <?php if($errors->has('id_master')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('id_master')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>


                            <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Tipo de Carrera</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>">

                                    <?php if($errors->has('name')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('hipodromo') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Hipodromo</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="hipodromo" value="<?php echo e(old('hipodromo')); ?>">

                                    <?php if($errors->has('hipodromo')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('hipodromo')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('pago') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Pago</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="pago" value="<?php echo e(old('pago')); ?>">

                                    <?php if($errors->has('pago')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('pago')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('distancia') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Distancia</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="distancia" value="<?php echo e(old('distancia')); ?>">

                                    <?php if($errors->has('distancia')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('distancia')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>


                            <div class="form-group<?php echo e($errors->has('fecha') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Fecha y Hora</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control datepicker" id="datetimepicker" placeholder="1999/12/31 14:32" name="fecha" value="<?php echo e(old('fecha')); ?>">

                                    <?php if($errors->has('fecha')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('fecha')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>




                            <div class="form-group<?php echo e($errors->has('terreno') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Terreno</label>

                                <div class="col-md-6">
                                    <select class="form-control" name="terreno">
                                        <option>Seleciona el Terreno de la Carrera</option>

                                        <option value="arena">arena</option>
                                        <option value="grava">grava</option>
                                        <option value="cesped">cesped</option>

                                    </select>
                                    <?php if($errors->has('tipo')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('tipo')); ?></strong>
                                    </span>
                                    <?php endif; ?>


                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('caballos_numero') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Numero de Corrida</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="caballos_numero" value="<?php echo e(old('caballos_numero')); ?>">

                                    <?php if($errors->has('caballos_numero')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('caballos_numero')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>








                            <div class="form-group">
                                <div class="col-md-6 col-md-offset-4">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fa fa-btn fa-user"></i>Agregar Polla
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
   

    <script src="<?php echo e(asset('DateTimePicker/jquery.datetimepicker.full.js')); ?>"></script>
    <script>
        $.datetimepicker.setLocale('es');
        $('#datetimepicker').datetimepicker({
            formatDate:'Y.m.d',
            dayOfWeekStart : 1,
            lang:'en',
            disabledDates:['1986/01/08','1986/01/09','1986/01/10'],
            startDate:	'now'
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>