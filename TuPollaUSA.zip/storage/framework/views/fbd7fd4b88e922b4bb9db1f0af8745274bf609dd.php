<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">

            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Agregar Caballos</div>
                    <div class="panel-body">
                        <div class="alert alert-success" role="alert">Le recordamos que el registro no se podra modificar en el futuro.</div>
                        <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/admin/caballo/editar')); ?>">
                            <?php echo csrf_field(); ?>


                            <div class="form-group<?php echo e($errors->has('id_polla') ? ' has-error' : ''); ?>">


                                <div class="col-md-6">


                                    <?php if($errors->has('id_master')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('id_master')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('id_polla') ? ' has-error' : ''); ?>">


                                <div class="col-md-6">


                                    <?php if($errors->has('id_master')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('id_master')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Nombre</label>
                                <input type="hidden" class="form-control" name="id" value="<?php echo e($caballo->id_caballo); ?>">
                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="name" value="<?php echo e($caballo->name); ?>" >

                                    <?php if($errors->has('name')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('posicion') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Posicion</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="posicion" value="<?php echo e($caballo->posicion); ?>"  readonly>

                                    <?php if($errors->has('posicion')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('posicion')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('propietario') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Propietario</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="propietario" placeholder="" value="<?php echo e($caballo->propietario); ?>">

                                    <?php if($errors->has('propietario')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('propietario')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('entrenador') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Entrenador</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="entrenador" placeholder="" value="<?php echo e($caballo->entrenador); ?>">

                                    <?php if($errors->has('entrenador')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('entrenador')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('jinete') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Jinete</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="jinete" placeholder="" value="<?php echo e($caballo->jinete); ?>">

                                    <?php if($errors->has('jinete')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('jinete')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('peso') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Peso</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="peso" placeholder="132" value="<?php echo e($caballo->peso); ?>">

                                    <?php if($errors->has('peso')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('peso')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('mi') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">MI</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="mi" placeholder=12/1" value="<?php echo e($caballo->mi); ?>">

                                    <?php if($errors->has('mi')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('mi')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-6 col-md-offset-4">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fa fa-btn fa-user"></i>Actualizar Caballo
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    
    <script>

        $('.datepicker').datepicker({
            format: "yyyy/mm/dd",
            language: "es",
            autoclose: true
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>