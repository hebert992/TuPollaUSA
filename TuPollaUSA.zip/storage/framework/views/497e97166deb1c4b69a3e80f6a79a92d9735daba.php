<?php $__env->startSection('content'); ?>
    <?php echo $__env->make("parcial.Mensajes", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<center>


    <p>
    <h3 class="text-center">Programacion</h3>
    A continuacion se publican las carreras en las que se jugara la polla esta semana; se les recuerda a nustros distinguidos clientes que la polla se juagara el sabado en las ultimas 6 carreras del Hipodromo Gulfstream Park
    </p>
    <input type="hidden" class="form-control" name="id_nada" value="<?php echo e($count1=0); ?>">
<?php foreach($pollas as $polla): ?>
    <input type="hidden" class="form-control" name="id_nada" value="<?php echo e($count=0); ?>">
        <input type="hidden" class="form-control" name="id_nada" value="<?php echo e($count1++); ?>">

        <li class="dropdown">
            <a href="#" class="dropdown-toggle btn btn-primary" data-toggle="dropdown"> Carrera <?php echo e($polla->caballos_numero); ?> <?php echo e($polla->hipodromo); ?>  TupollaUSA.com  <b class="caret"></b></a>
            <ul class="dropdown-menu">
                <li>

                    <div class="panel panel-default">

                        <div class="panel-body">
                            <ul>
                                <li><b>Fecha y Hora:</b> <?php echo e($polla->fecha); ?></li>
                                <li><b>Tipo de Carrera:</b> <?php echo e($polla->name); ?></li>
                                <li><b>Purse:</b> $<?php echo e($polla->pago); ?></li>
                                <li><b>Distancia:</b> <?php echo e($polla->distancia); ?></li>
                                <li><b>Terrerno:</b> <?php echo e($polla->terreno); ?></li>
                            </ul>
                        </div>


                        <table class="table table-striped table-hover">
                            <tr>
                                <td><b>Puerta</b></td>
                                <td><b>Caballo</b></td>
                                <td><b>Dueño</b></td>
                                <td><b>Jinete</b></td>
                                <td><b>Entrenador</b></td>
                                <td><b>Peso</b></td>
                                <td><b>MI</b></td>

                            </tr>

                                <?php foreach($caballos as $caballo): ?>
                                    <?php if($caballo->id_polla===$polla->id_polla): ?>
                                    <tr>
                                        <input type="hidden" class="form-control" name="id_nada" value="<?php echo e($count+=1); ?>">
                                <td class="caballo<?php echo e($count); ?>"><b><?php echo e($count); ?></b></td>
                                <td><?php echo e($caballo->name); ?></td>
                                <td><?php echo e($caballo->propietario); ?></td>
                                <td><?php echo e($caballo->jinete); ?></td>
                                <td><?php echo e($caballo->entrenador); ?></td>
                                <td><?php echo e($caballo->peso); ?></td>
                                <td><?php echo e($caballo->mi); ?></td>
                                    </tr>
                                    <?php endif; ?>
                                <?php endforeach; ?>


                        </table>
                    </div>
                </li>
            </ul>
        </li>

<?php endforeach; ?>
    <br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>