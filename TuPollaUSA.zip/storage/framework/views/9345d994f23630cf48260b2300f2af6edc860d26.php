<?php $__env->startSection('content'); ?>

    <div class="container">

        <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="panel panel-default">
        <div class="panel-heading">Noticias </div>
            <div class="panel-body">
            <a class="btn btn-primary pull-right" style="margin-top: 25px" href="<?php echo route('noticias.create'); ?>">Crear Noticia</a>



            <?php if($noticias->isEmpty()): ?>
                <div class="well text-center">No existen noticias.</div>
            <?php else: ?>
                <table class="table">
                    <thead>
                    <th>Titulo</th>

			<th>Autor</th>
                    <th width="50px">Acciones</th>
                    </thead>
                    <tbody>
                     
                    <?php foreach($noticias as $noticias): ?>
                        <tr>
                            <td><?php echo $noticias->titulo; ?></td>

					<td><?php echo $noticias->autor; ?></td>
                            <td>
                                <a href="<?php echo route('noticias.edit', [$noticias->id]); ?>"><i class="glyphicon glyphicon-edit"></i></a>
                                <a href="<?php echo route('noticias.delete', [$noticias->id]); ?>" onclick="return confirm('Are you sure wants to delete this noticias?')"><i class="glyphicon glyphicon-remove"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>