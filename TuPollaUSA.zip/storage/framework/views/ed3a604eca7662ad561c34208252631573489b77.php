<?php if(Session::has('flash_danger')): ?>

    <div class="alert alert-danger" role="alert"><?php echo e(Session::get('flash_danger')); ?></div>


<?php endif; ?>

<?php if(Session::has('flash_success')): ?>

    <div class="alert alert-success" role="alert"><?php echo e(Session::get('flash_success')); ?></div>
    <?php echo e(Session::flush()); ?>


<?php endif; ?>