<?php echo $__env->make("parcial.Mensajes", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>

    <div class="panel panel-default">
        <div class="panel-heading">Lita de apuestas</div>
        <div class="panel-body">
            <table class="table table-hover">
               <form role="search"method="GET"  action="<?php echo e(url("/admin/apuestas/list")); ?>">
                    <div class="col-lg-6">
                        <div class="input-group">
                            <input name="name" type="text" class="form-control" placeholder="Buscar por ID de apuesta">
      <span class="input-group-btn">
        <button class="btn btn-default" type="submit">Buscar</button>
      </span>
                        </div><!-- /input-group -->
                    </div><!-- /.col-lg-6 -->
                </form>
        </div><!-- /.row -->
                <tr>
                    <td><h4>#</h4></td>
                    <td><h4>Nick</h4></td>

                    <td><h4>ID Apuesta</h4></td>
                </tr>
                <?php foreach($apuestas as $apuesta): ?>
                    <tr>
                        <td><?php echo e($apuesta->id_apuesta); ?></td>
                        <td><?php echo e(\App\User::findOrFail($apuesta->id_cliente)->nick); ?></td>
                        <td> <a href="<?php echo e(url("/verificar/".$apuesta->id_apuesta)); ?>"><?php echo e($apuesta->id_apuesta); ?></a></td>
                    </tr>
                <?php endforeach; ?>


            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>