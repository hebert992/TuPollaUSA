<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="panel-default">
    <div class="panel-heading"> <?php echo $noticias->titulo; ?></div>
        <div class="panel-body">
            <?php echo $noticias->contenido; ?>

        </div>
        <div class="panel-footer">Publicado: <?php echo e($noticias->created_at); ?>

    </div>
</div>
    <br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>