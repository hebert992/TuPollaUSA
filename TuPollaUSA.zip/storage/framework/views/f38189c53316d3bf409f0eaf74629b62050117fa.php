<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Register</div>
                    <div class="panel-body">
                        <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/tienda/registro')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="form-group<?php echo e($errors->has('nick') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Nombre de Usuario</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="nick" value="<?php echo e(old('nick')); ?>">

                                    <?php if($errors->has('nick')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('nick')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Correo</label>

                                <div class="col-md-6">
                                    <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>">

                                    <?php if($errors->has('email')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Nombre</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>">

                                    <?php if($errors->has('name')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('apellido') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Apellido</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="apellido" value="<?php echo e(old('apellido')); ?>">

                                    <?php if($errors->has('name')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('apellido')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('telefono') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Telefono</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="telefono" value="<?php echo e(old('telefono')); ?>">

                                    <?php if($errors->has('telefono')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('telefono')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('pais') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Pais</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="pais" value="<?php echo e(old('pais')); ?>">

                                    <?php if($errors->has('pais')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('pais')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('ciudad') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Ciudad</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="ciudad" value="<?php echo e(old('ciudad')); ?>">

                                    <?php if($errors->has('ciudad')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('ciudad')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('direccion') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Direccion</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="direccion" value="<?php echo e(old('direccion')); ?>">

                                    <?php if($errors->has('direccion')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('direccion')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>


                            <div class="form-group<?php echo e($errors->has('date') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Fecha de Nacimiento</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control  datepicker" placeholder="1992/12/31" name="date" value="<?php echo e(old('date')); ?>">

                                    <?php if($errors->has('date')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('date')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>


                            <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Contraseña</label>

                                <div class="col-md-6">
                                    <input type="password" class="form-control" name="password">

                                    <?php if($errors->has('password')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
                                <label class="col-md-4 control-label">Confirmar contraseña</label>

                                <div class="col-md-6">
                                    <input type="password" class="form-control" name="password_confirmation">

                                    <?php if($errors->has('password_confirmation')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-6 col-md-offset-4">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fa fa-btn fa-user"></i>Registrar
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    
    <script>
        $('.datepicker').datepicker({
            format: "yyyy/mm/dd",
            language: "es",
            autoclose: true
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>