<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="alert alert-success" role="alert">POLLA : <?php echo e($polla->name); ?> -- PAGO :  <?php echo e($polla->pago); ?> -- FECHA :  <?php echo e($polla->fecha); ?></div>
                <div class="panel panel-default">
                    <?php echo $__env->make("parcial.Mensajes", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <div class="panel-heading">Lista de Caballos de la polla</div>

                    <div class="panel-body">
                        <div class="panel-body">
                            <table class="table table-striped">
                                <tr>
                                    <th>Nombre</th>
                                    <th>Propietario</th>
                                    <th>Jinete</th>
                                    <th>Peso</th>
                                    <th>MI</th>
                                    <th>Acciones</th>

                                </tr>
                                <?php foreach( $caballos as $caballo): ?>
                                    <tr>
                                        <td><?php echo e($caballo->name); ?></td>
                                        <td><?php echo e($caballo->propietario); ?></td>
                                        <td><?php echo e($caballo->jinete); ?></td>
                                        <td><?php echo e($caballo->peso); ?></td>
                                        <td><?php echo e($caballo->mi); ?></td>
                                        <td>
                                            <div class="btn-group">
                                                <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    Herramientas <span class="caret"></span>
                                                </button>
                                                <ul class="dropdown-menu">
                                                    <li><a href="<?php echo e(url("/admin/caballo/editar/$caballo->id_caballo")); ?>">Editar</a></li>


                                                </ul>

                                            </div>

                                        </td>

                                    </tr>
                                <?php endforeach; ?>
                            </table>


                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>