<?php $__env->startSection('content'); ?>
    <?php echo $__env->make("parcial.Mensajes", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="panel-body">
     <h4>   <b> Le recordamos que esta apostando en nombre de : <?php echo e($user->nick); ?></b></h4>
    </div>

    <div class="">
        <b> Selecciona un caballo para Cada una de las carreras verifica tu seleccion y cuando estes listo dale al boton enviar polla </b>
    </div>
    <form action="<?php echo e(url("/tienda/apuesta")); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <input type="hidden" class="form-control" name="no sire" value="<?php echo e($count=0); ?>">
        <input type="hidden" class="form-control" name="id_master" value="<?php echo e($master); ?>">
        <input type="hidden" class="form-control" name="id_cliente" value="<?php echo e($user->id); ?>">
        <?php foreach($pollas as $polla): ?>
            <div class="panel panel-default">
                <div class="panel-heading">Carrera <?php echo e($polla->id_polla); ?> <?php echo e($polla->hipodromo); ?>   TupollaUSA.com <?php echo e($polla->fecha); ?> </div>
                <input type="hidden" class="form-control" name="no sire" value="<?php echo e($count+=1); ?>">
                <input type="hidden" class="form-control" name="id_polla<?php echo e($count); ?>" value="<?php echo e($polla->id_polla); ?>">

                <div class="panel-body">
                    <p>
                        Seleccione el caballo de su preferencia para esta carrera
                    </p>
                    <select id="id<?php echo e($count); ?>"class="form-control" name="id_caballo<?php echo e($count); ?>" >
                        <?php foreach($caballos as $caballo): ?>
                            <?php if($polla->id_polla === $caballo->id_polla): ?>
                                <option value="<?php echo e($caballo->id_caballo); ?>"><?php echo e($caballo->posicion); ?></option >
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </select>
                    <div class="panel-body" id="body<?php echo e($count); ?>">

                    </div>

                </div>



            </div>
        <?php endforeach; ?>
        <div class="form-group">
            <div class="col-md-6 col-md-offset-4">
                <button type="submit" class="btn btn-primary">
                    <i class="btn-lg">APOSTAR!</i>
                </button>
            </div>
        </div>
    </form>

    <script src="<?php echo e(asset('js/caballos.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>