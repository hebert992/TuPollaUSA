<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Confirmacion de polla</title>

</head>
<body>

<main >
    <div style="text-align:center;">
    <div id="details" class="clearfix">
        <div id="invoice">
            <h1>ID Polla: <?php echo e($factura->id_apuesta); ?></h1>
            <h2 class="date">Stud: <?php echo e(\App\User::find($factura->id_cliente)->nick); ?></h2>
            <div class="date">Fecha: <?php echo e($factura->created_at); ?></div>

        </div>
    </div>

    <table border="0" cellspacing="0" cellpadding="0">

        <tr>
            <th >#</th>
            <th >Apuesta</th>
            <th>Caballo</th>

        </tr>



        <tr>
            <td ><?php echo e(1); ?>   ---   </td>

            <td><?php echo e($po= \App\pollas::find($factura->id_polla1)->name); ?>   ---    </td>
            <td ><?php echo e($cab1= \App\caballos::find($factura->id_caballo1)->posicion); ?> <?php echo e(\App\caballos::find($factura->id_caballo1)->name); ?></td>
        </tr>
        <tr>
            <td ><?php echo e(2); ?>   ---   </td>

            <td><?php echo e($po1= \App\pollas::find($factura->id_polla2)->name); ?>   ---    </td>
            <td ><?php echo e($cab1= \App\caballos::find($factura->id_caballo2)->posicion); ?> <?php echo e(\App\caballos::find($factura->id_caballo2)->name); ?></td>
        </tr>
        <tr>
            <td ><?php echo e(3); ?>   ---   </td>

            <td><?php echo e($p2= \App\pollas::find($factura->id_polla3)->name); ?>   ---    </td>
            <td ><?php echo e($cab1= \App\caballos::find($factura->id_caballo3)->posicion); ?> <?php echo e(\App\caballos::find($factura->id_caballo3)->name); ?></td>
        </tr>
        <tr>
            <td ><?php echo e(4); ?>   ---   </td>

            <td><?php echo e($p3= \App\pollas::find($factura->id_polla4)->name); ?>   ---    </td>
            <td ><?php echo e($cab1= \App\caballos::find($factura->id_caballo4)->posicion); ?> <?php echo e(\App\caballos::find($factura->id_caballo4)->name); ?></td>
        </tr>
        <tr>
            <td ><?php echo e(5); ?>   ---   </td>

            <td><?php echo e($po= \App\pollas::find($factura->id_polla5)->name); ?>   ---    </td>
            <td ><?php echo e($cab1= \App\caballos::find($factura->id_caballo5)->posicion); ?> <?php echo e(\App\caballos::find($factura->id_caballo5)->name); ?></td>
        </tr>
        <tr>
            <td ><?php echo e(6); ?>   ---   </td>

            <td><?php echo e($po= \App\pollas::find($factura->id_polla6)->name); ?>   ---    </td>
            <td ><?php echo e($cab1= \App\caballos::find($factura->id_caballo6)->posicion); ?> <?php echo e(\App\caballos::find($factura->id_caballo6)->name); ?></td>
        </tr>



    </table>
</div>


 <div style="text-align:right;">
    <?php if($factura->id_master != null): ?>
         Facturado por: <?php echo e(\App\User::find($factura->id_master)->nick); ?>


    <?php else: ?>
        Facturado por: WEB
   <?php endif; ?>
</div>
</body>

</html>