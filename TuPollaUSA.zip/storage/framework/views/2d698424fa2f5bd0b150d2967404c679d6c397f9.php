<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8">
</head>
<body>
<center>
   <img src=" <?php echo e(asset("/img/logo-mail.jpg")); ?>">
</center>
<h4>Correo de confirmacion de polla</h4>
<h2>Sr(a) <?php echo e($nick); ?></h2>

<div>

   <br>Gracias por TuPollaUSA en este correo le enviamos un archivo adjunto donde se confirma su apuesta <br/>

    <br>Le recomendamos guardar este archivo para comprobar su apuesta en caso de ganar<br/>

    <br>Le recomendamos guardar este archivo para comprobar su apuesta en caso de ganar<br/>
    <br><br/>
    <br><br/>
    <br>Le recordamos que esta direccion de correo no es monitoreada<br/>
</div>

</body>
</html>