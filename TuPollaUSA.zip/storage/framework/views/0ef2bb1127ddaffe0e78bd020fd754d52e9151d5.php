<?php echo $__env->make("parcial.Mensajes", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
    <table class="table table-hover">

        <tr>

            <td><h3>Posicion</h3></td>
            <td><h3>Nick</h3></td>
            <td><h3>Puntos</h3></td>
            <td><h3>ID Apuesta</h3></td>
        </tr>

            <?php foreach($definitiva as $definitivas): ?>
            <tr>
            <td><?php echo e($final+=1); ?></td>
            <td><?php echo e($definitivas[0]); ?></td>
            <td><?php echo e($definitivas[1]); ?></td>
            <td><?php echo e($definitivas[2]); ?></td>
        </tr>
            <?php endforeach; ?>


    </table>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>