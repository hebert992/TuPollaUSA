<?php echo $__env->make("parcial.Mensajes", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>

    <div class="panel panel-default">
        <div class="panel-heading">Tabla de ganadores</div>
        <div class="panel-body">
    <table class="table table-hover">

        <tr>

            <td><h4>Posicion</h4></td>
            <td><h4>Nick</h4></td>
            <td><h4>Puntos</h4></td>
            <td><h4>ID Apuesta</h4></td>
        </tr>

            <?php foreach($definitiva as $definitivas): ?>
            <tr>
            <td><?php echo e($final+=1); ?></td>
            <td><?php echo e($definitivas[0]); ?></td>
            <td><?php echo e($definitivas[1]); ?></td>
            <td> <a href="<?php echo e(url("/verificar/".$definitivas[2])); ?>"><?php echo e($definitivas[2]); ?></a></td>
        </tr>
            <?php endforeach; ?>


    </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>