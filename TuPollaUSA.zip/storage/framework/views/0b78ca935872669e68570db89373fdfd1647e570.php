<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading">Lista de recargas</div>
                   <?php echo $__env->make("parcial.Mensajes", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <div class="panel-body">

                        <?php if( Auth::user()->rol=="admin"): ?>
                            <a class="btn btn-info" href="<?php echo e(url('/admin/registro')); ?>" role="button">
                                Nueva Tienda
                            </a>
                        <?php endif; ?>
                        <?php if( Auth::user()->rol=="tienda"): ?>
                            <a class="btn btn-info" href="<?php echo e(url('/tienda/registro')); ?>" role="button">
                                Nuevo usuario
                            </a>
                        <?php endif; ?>

                        <form class="navbar-form navbar-right" role="search"method="GET" >

                            <input type="text" class="form-control"  name="name"  placeholder="Nombre del cliente"  >

                            <button type="submit" class="btn btn-default">Buscar</button>

                        </form>

                            <form class="navbar-form navbar-right" role="search"method="GET" >

                                <input type="text" class="form-control  datepicker" placeholder="Desde " name="date1" value="<?php echo e(old('date1')); ?>">
                                <input type="text" class="form-control  datepicker" placeholder="Hasta " name="date2" value="<?php echo e(old('date2')); ?>">

                                <button type="submit" class="btn btn-default">Buscar</button>

                            </form>


                        <table class="table table-striped">



                            <tr>
                                <th>Para</th>
                                <th>Tienda</th>
                                <th>Fecha</th>
                                <th>Monto BSF</th>
                                <th>Tipo</th>
                                <th>Acciones</th>

                            </tr>
                            <?php foreach( $recargass as $recargas): ?>
                                    <!-- Modal -->
                            <div class="modal fade" id="detalles<?php echo e($recargas->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                            <h4 class="modal-title" id="exampleModalLabel">Informacion detalla de la recarga</h4>
                                        </div>
                                        <div class="modal-body">
                                            <form>
                                                <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                                    <label class="col-md-4 control-label">ID De la Transaccion</label>
                                                    <input type="text" class="form-control" name="id" value="<?php echo e($recargas->id); ?>" readonly>
                                                </div>
                                                <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                                    <label class="col-md-4 control-label">ID del Stud</label>
                                                    <input type="text" class="form-control" name="id" value="<?php echo e($recargas->id_cliente); ?>" readonly>
                                                </div>
                                                <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                                    <label class="col-md-4 control-label">Transaccion a favor de </label>
                                                    <input type="text" class="form-control" name="id" value="<?php echo e($recargas->nick); ?>" readonly>
                                                </div>
                                                <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                                    <label class="col-md-4 control-label">Monto</label>
                                                    <input type="text" class="form-control" name="id" value="<?php echo e($recargas->monto); ?>" readonly>
                                                </div>
                                                <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                                    <label class="col-md-4 control-label">Tipo</label>
                                                    <input type="text" class="form-control" name="id" value="<?php echo e($recargas->tipo); ?>" readonly>
                                                </div>
                                                <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                                    <label class="col-md-4 control-label">Referencia</label>
                                                    <input type="text" class="form-control" name="id" value="<?php echo e($recargas->referencia); ?>" readonly>
                                                </div>
                                                <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                                    <label class="col-md-4 control-label">Stud que realizo la recarga</label>
                                                    <input type="text" class="form-control" name="id" value="<?php echo e($recargas->master); ?>" readonly>
                                                </div>
                                                <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                                    <label class="col-md-4 control-label">Fecha y Hora de Recarga</label>
                                                    <input type="text" class="form-control" name="id" value="<?php echo e($recargas->created_at); ?>" readonly>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Modal -->

                            <div class="modal fade" id="recarga<?php echo e($recargas->id); ?>" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
                                <div class="modal-dialog modal-sm">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                            <h4 class="modal-title">Seguro de Eliminar esta recarga</h4>
                                        </div>
                                        <div class="modal-body">

                                            <form class="row" method="post" action="<?php echo e(url('/admin/borrar/recarga')); ?>">


                                                <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                                    <label class="col-xs-8 .col-sm-6 control-label">ID Recarga </label>
                                                    <input type="text" class="form-control  .col-xs-4 .col-sm-6" name="id_transaccion" value="<?php echo e($recargas->id); ?>" readonly>
                                                </div>
                                                <?php echo csrf_field(); ?>

                                                <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                                    <label class="col-xs-8 .col-sm-6 control-label">De</label>
                                                    <input type="text" class="form-control  .col-xs-4 .col-sm-6" name="master" value="<?php echo e($recargas->master); ?>" readonly>
                                                </div>
                                                <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                                    <label class="col-xs-8 .col-sm-6 control-label">Para</label>
                                                    <input type="text" class="form-control  .col-xs-4 .col-sm-6" name="nick" value="<?php echo e($recargas->nick); ?>" readonly>
                                                </div>
                                                <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                                    <label class="col-xs-8 .col-sm-6 control-label">Monto</label>
                                                    <input type="text" class="form-control  .col-xs-4 .col-sm-6" name="monto" value="<?php echo e($recargas->monto); ?>" readonly>
                                                </div>




                                        </div>
                                        <div class="modal-footer">

                                            <button type="submit" class="btn btn-primary">Eliminar Recarga</button>
                                            </form>
                                        </div>
                                    </div><!-- /.modal-content -->
                                </div><!-- /.modal-dialog -->
                            </div><!-- /.modal -->

                                <tr>
                                    <td><?php echo e($recargas->nick); ?></td>
                                    <td><?php echo e($recargas->master); ?></td>
                                    <td><?php echo e($recargas->created_at); ?></td>
                                    <td><?php echo e($recargas->monto); ?></td>
                                    <td><?php echo e($recargas->tipo); ?></td>

                                    <td>
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                Herramientas <span class="caret"></span>
                                            </button>
                                            <ul class="dropdown-menu">
                                                <li><a data-toggle="modal" data-target="#detalles<?php echo e($recargas->id); ?>" href="#">Detalles</a></li>

                                                <li role="separator" class="divider"></li>
                                                <li><a data-toggle="modal" data-target="#recarga<?php echo e($recargas->id); ?>" href="#">Eliminar</a></li>
                                            </ul>

                                        </div>

                                    </td>
                                </tr>

                            <?php endforeach; ?>
                        </table>


                        <?php echo $recargass->render(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        $('.datepicker').datepicker({
            format: "yyyy/mm/dd",
            language: "es",
            autoclose: true
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>