<?php $__env->startSection("content"); ?>
    <div>
        <div class="msg_box" style="right:290px">
            <div class="msg_head">Chat General

            </div>
            <div class="msg_wrap">
                <div id="chat" class="msg_body">

                </div>
                <div class="msg_footer"><textarea class="msg_input" rows="4"></textarea></div>
            </div>
        </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>